<?php
require_once __DIR__ . '/../includes/auth.php';
require_admin();
refresh_amc_statuses($pdo);

$page_title = 'Dashboard';
$active = 'dashboard';

$total_customers = $pdo->query("SELECT COUNT(*) c FROM customers")->fetch()['c'];
$total_amc = $pdo->query("SELECT COUNT(*) c FROM amc_contracts")->fetch()['c'];
$active_amc = $pdo->query("SELECT COUNT(*) c FROM amc_contracts WHERE status='active'")->fetch()['c'];
$expiring_amc = $pdo->query("SELECT COUNT(*) c FROM amc_contracts WHERE status='expiring'")->fetch()['c'];
$expired_amc = $pdo->query("SELECT COUNT(*) c FROM amc_contracts WHERE status='expired'")->fetch()['c'];
$total_technicians = $pdo->query("SELECT COUNT(*) c FROM users WHERE role='technician'")->fetch()['c'];
$unpaid_invoices = $pdo->query("SELECT COUNT(*) c FROM invoices WHERE status='unpaid'")->fetch()['c'];

$recent_visits = $pdo->query("
    SELECT v.*, c.name AS customer_name, u.name AS tech_name
    FROM visits v
    JOIN amc_contracts a ON v.amc_id = a.id
    JOIN customers c ON a.customer_id = c.id
    JOIN users u ON v.technician_id = u.id
    ORDER BY v.created_at DESC LIMIT 6
")->fetchAll();

$expiring_list = $pdo->query("
    SELECT a.*, c.name AS customer_name, c.mobile
    FROM amc_contracts a JOIN customers c ON a.customer_id = c.id
    WHERE a.status = 'expiring'
    ORDER BY a.end_date ASC LIMIT 6
")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="stats-grid">
    <div class="stat-card">
        <div class="num"><?= $total_customers ?></div>
        <div class="label">Total Customers</div>
    </div>
    <div class="stat-card success">
        <div class="num"><?= $active_amc ?></div>
        <div class="label">Active AMCs</div>
    </div>
    <div class="stat-card warning">
        <div class="num"><?= $expiring_amc ?></div>
        <div class="label">Expiring Soon (30 days)</div>
    </div>
    <div class="stat-card danger">
        <div class="num"><?= $expired_amc ?></div>
        <div class="label">Expired AMCs</div>
    </div>
    <div class="stat-card">
        <div class="num"><?= $total_technicians ?></div>
        <div class="label">Technicians</div>
    </div>
    <div class="stat-card danger">
        <div class="num"><?= $unpaid_invoices ?></div>
        <div class="label">Unpaid Invoices</div>
    </div>
</div>

<div class="grid-2">
    <div class="card">
        <div class="card-header"><h3>⏰ AMCs Expiring Soon</h3><a href="expiring_amc.php" class="btn btn-sm btn-outline">View All</a></div>
        <div class="table-wrap">
        <table>
            <tr><th>Customer</th><th>Mobile</th><th>End Date</th></tr>
            <?php if (!$expiring_list): ?>
                <tr><td colspan="3" style="text-align:center;color:#6b7280;">Koi AMC expire nahi ho raha</td></tr>
            <?php endif; ?>
            <?php foreach ($expiring_list as $r): ?>
                <tr>
                    <td><?= e($r['customer_name']) ?></td>
                    <td><a href="https://wa.me/91<?= e($r['mobile']) ?>" class="whatsapp-link" target="_blank"><?= e($r['mobile']) ?></a></td>
                    <td><?= e($r['end_date']) ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><h3>🧾 Recent Visit Reports</h3></div>
        <div class="table-wrap">
        <table>
            <tr><th>Customer</th><th>Technician</th><th>Date</th><th>Status</th></tr>
            <?php if (!$recent_visits): ?>
                <tr><td colspan="4" style="text-align:center;color:#6b7280;">Abhi tak koi visit report nahi</td></tr>
            <?php endif; ?>
            <?php foreach ($recent_visits as $v): ?>
                <tr>
                    <td><?= e($v['customer_name']) ?></td>
                    <td><?= e($v['tech_name']) ?></td>
                    <td><?= e($v['visit_date']) ?></td>
                    <td><?= $v['issue_resolved'] ? '<span class="badge badge-active">Resolved</span>' : '<span class="badge badge-expiring">Pending</span>' ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
